class SpyUrlMappings {
    static mappings = {
      "/spy/$action?/$path**?"{
	      controller = 'spy'
	  }
	}
}
